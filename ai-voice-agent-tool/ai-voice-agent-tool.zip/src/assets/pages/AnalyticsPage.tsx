import React from "react";

const AnalyticsPage = () => (
  <div className="space-y-6">
    <h2 className="text-2xl font-semibold">Analytics</h2>
    <div className="panel p-6">
      <p className="text-[var(--muted)]">
        Add charts here (Recharts/Chart.js). For now, this is a placeholder container.
      </p>
    </div>
  </div>
);

export default AnalyticsPage;
