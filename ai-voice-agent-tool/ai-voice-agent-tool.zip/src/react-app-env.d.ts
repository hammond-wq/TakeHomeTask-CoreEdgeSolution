/// <reference types="react-scripts" />

declare module "*.jsx" {
  const value: any;
  export default value;
}
