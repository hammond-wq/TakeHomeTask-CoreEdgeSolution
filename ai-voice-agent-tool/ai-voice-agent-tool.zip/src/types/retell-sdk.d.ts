// src/types/retell-sdk.d.ts
declare module "retell-sdk" {
  const mod: any;
  export default mod;
}
